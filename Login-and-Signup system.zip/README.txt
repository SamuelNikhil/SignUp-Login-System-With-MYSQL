//I made this login and signup system while im learning PHP

It covers :
	-HTML
	-CSS
	-JavaScript - Links HTML with PHP
	-PHP
		*COOKIES
		*SESSIONS
		*MVP PATTERN
	-SQL